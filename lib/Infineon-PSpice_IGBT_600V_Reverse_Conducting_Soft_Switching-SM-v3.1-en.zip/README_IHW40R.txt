* THESE MODEL VERSION WAS TESTED ON PSPICE A/D 16  *
* Models included:
* IHW40N60R			600	40 			*	
* IHW40N60RF			600	40 			*
==============================================================
PSPICE how to use PSPICE libraries
Date: Feb 2010
==============================================================

The library is comprised of the following files:
------------------------------------------------
The xxx.LIB file represents the Spice model library. 

The xxx.SLB file contains the terminal/graphics information 
required by the PSpice graphic user interface "Schematics".

The xxx.OLB file contains the terminal/graphics information 
required by the PSpice graphic user interface "ORCAD CAPTURE".


INSTALLATION
------------
To install the library, copy all xxx.LIB,xxx.SLB and xxx.OLB files 
into your directory: 

  x:\"PSpice working directory"\(user-)LIB\ 

The library files must then be activated before beeing use with PSpice. 

--------------------  S C H E M A T I C S ----------------------------

Proceed as follows when using the program SCHEMATICS:

1.Install the library file xxx.LIB as a permanent 
  library ("ADD LIBRARY*") in submenu 
  ANALYSIS -> LIBRARY AND INCLUDE FILES ... 

2.Install the symbol data file xxx.SLB for the
  "Schematics" graphic interface in submenu
  OPTIONS -> EDITOR CONFIGURATION -> LIBRARY SETTINGS

--------------------  C A P T U R E      ----------------------------

Proceed as follows when using the program ORCAD CAPTURE:

1.Install the graphics file xxx.OLB as a permanent 
  library ("ADD LIBRARY*") in submenu 
  PLACE PART -> ADD LIBRARY ... 

2.Install the library file xxx.LIB for the
  "CAPTURE" graphic interface in submenu
  SIMULATION SETTINGS -> LIBRARIES -> ADD AS GLOBAL/ADD TO SIMULATION


*===================================================================*

For modelling, we recommend to set the following options in
"OPTIONS" section of the respective program (CAPTURE / SCHEMATICS)

* ITL1 = 400 ITL2 = 200 ITL4 > 200 ABSTOL = 1u RELTOL = 5m GMIN = 1n VNTOL = 10n

*===================================================================*
If the following error message appears while simulating one of the
device models:

====>  INTERNAL ERROR -- Overflow in device ........   <=====

Then the 'PSPICE.INI' file has to be edited.

Please insert the following line behind the headline [PSPICE] as
follows:

[PSPICE]
MathExceptions = off
......
DO NOT CHANGE THE OTHER LINES ALLREADY PRESENT
......


=====================================================================
* Note:                                                             *
* Altough models can be a useful tool in evaluating device          *
* performance, they cannot model exact device performance           *
* under all conditions, nor are they intended to replace            *
* breadboarding for final verification!                             *
*                                                                   *
* Models provided by INFINEON TECHNOLOGIES AG are not warranted by  *
* INFINEON TECHNOLOGIES AG				            *
* as fully representing all of the specifications and operating     *
* characteristics of the semiconductor product to which the         *
* model relates.                                                    *
* The models describe the characteristics of typical devices.       *
* In all cases, the current data sheet information for a given      *
* device is the final design guideline and the only actual          *
* performance specification.                                        * 
* INFINEON TECHNOLOGIES AG does not assume any liability arising    *
* from the model use. INFINEON TECHNOLOGIES AG reserves the right to*
* change models without prior notice.				    *
*                                                                   *
* This disclaimer is a part of the respective library files !       *
=====================================================================
